// Funções para gerenciamento de documentos (PDFs)

// Elementos DOM para documentos
let documentUploadModal;
let documentUploadForm;
let currentBimester = 1;
let currentSubject = '';

// Inicialização adicional para documentos
document.addEventListener('DOMContentLoaded', function() {
    // Configuração anterior mantida...
    
    // Configurar eventos de documentos
    setupDocumentEvents();
});

// Configurar eventos relacionados a documentos
function setupDocumentEvents() {
    // Botão para abrir modal de upload de documento
    const uploadDocBtn = document.getElementById('upload-document-btn');
    if (uploadDocBtn) {
        uploadDocBtn.addEventListener('click', function() {
            showDocumentUploadModal();
        });
    }
    
    // Formulário de upload de documento
    documentUploadForm = document.getElementById('document-upload-form');
    if (documentUploadForm) {
        documentUploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            uploadDocument();
        });
    }
    
    // Seletores de bimestre e matéria para documentos
    const docBimesterSelect = document.getElementById('document-bimester');
    const docSubjectSelect = document.getElementById('document-subject');
    
    if (docBimesterSelect) {
        docBimesterSelect.addEventListener('change', function() {
            currentBimester = this.value;
            loadDocuments();
        });
    }
    
    if (docSubjectSelect) {
        docSubjectSelect.addEventListener('change', function() {
            currentSubject = this.value;
            loadDocuments();
        });
    }
    
    // Carregar documentos iniciais
    loadDocuments();
}

// Mostrar modal de upload de documento
function showDocumentUploadModal() {
    // Limpar formulário
    if (documentUploadForm) {
        documentUploadForm.reset();
    }
    
    // Mostrar modal
    documentUploadModal = new bootstrap.Modal(document.getElementById('documentUploadModal'));
    documentUploadModal.show();
}

// Upload de documento
function uploadDocument() {
    const fileInput = document.getElementById('document-file');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Selecione um arquivo PDF para upload.');
        return;
    }
    
    // Validar tipo de arquivo
    if (file.type !== 'application/pdf') {
        alert('Apenas arquivos PDF são permitidos.');
        return;
    }
    
    // Validar tamanho do arquivo (máximo 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB em bytes
    if (file.size > maxSize) {
        alert('O arquivo é muito grande. O tamanho máximo permitido é 10MB.');
        return;
    }
    
    // Obter dados do formulário
    const bimester = document.getElementById('upload-bimester').value;
    const subject = document.getElementById('upload-subject').value;
    const title = document.getElementById('document-title').value;
    const description = document.getElementById('document-description').value;
    
    // Validar campos obrigatórios
    if (!bimester || !subject || !title) {
        alert('Bimestre, matéria e título são obrigatórios.');
        return;
    }
    
    // Criar FormData para envio do arquivo
    const formData = new FormData();
    formData.append('file', file);
    formData.append('bimester', bimester);
    formData.append('subject', subject);
    formData.append('title', title);
    formData.append('description', description);
    
    // Mostrar indicador de carregamento
    const uploadBtn = document.getElementById('upload-document-btn');
    const originalBtnText = uploadBtn.innerHTML;
    uploadBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Enviando...';
    uploadBtn.disabled = true;
    
    fetch('/api/documents', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Restaurar botão
        uploadBtn.innerHTML = originalBtnText;
        uploadBtn.disabled = false;
        
        if (data.error) {
            alert(data.error);
        } else {
            // Fechar modal
            documentUploadModal.hide();
            
            // Atualizar lista de documentos
            loadDocuments();
            
            // Mostrar mensagem de sucesso
            alert('Documento enviado com sucesso!');
        }
    })
    .catch(error => {
        // Restaurar botão
        uploadBtn.innerHTML = originalBtnText;
        uploadBtn.disabled = false;
        
        console.error('Erro ao fazer upload do documento:', error);
        alert('Erro ao fazer upload do documento. Tente novamente.');
    });
}

// Carregar lista de documentos
function loadDocuments() {
    // Construir URL com filtros
    let url = '/api/documents';
    const params = new URLSearchParams();
    
    if (currentBimester) {
        params.append('bimester', currentBimester);
    }
    
    if (currentSubject) {
        params.append('subject', currentSubject);
    }
    
    if (params.toString()) {
        url += '?' + params.toString();
    }
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Erro ao carregar documentos:', data.error);
                return;
            }
            
            const documentsContainer = document.getElementById('documents-container');
            if (!documentsContainer) return;
            
            if (data.documents.length === 0) {
                documentsContainer.innerHTML = '<div class="alert alert-info">Nenhum documento encontrado para este bimestre/matéria.</div>';
                return;
            }
            
            // Limpar container
            documentsContainer.innerHTML = '';
            
            // Criar cards para cada documento
            data.documents.forEach(doc => {
                const card = createDocumentCard(doc);
                documentsContainer.appendChild(card);
            });
        })
        .catch(error => {
            console.error('Erro ao carregar documentos:', error);
        });
}

// Criar card para documento
function createDocumentCard(doc) {
    const card = document.createElement('div');
    card.className = 'card mb-3';
    
    // Formatar data de upload
    const uploadDate = new Date(doc.upload_date);
    const formattedDate = uploadDate.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    // Formatar tamanho do arquivo
    const fileSize = formatFileSize(doc.file_size);
    
    card.innerHTML = `
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start">
                <h5 class="card-title">${doc.title}</h5>
                <span class="badge bg-primary">${doc.subject} - ${doc.bimester}º Bimestre</span>
            </div>
            ${doc.description ? `<p class="card-text">${doc.description}</p>` : ''}
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div class="text-muted small">
                    <div>Enviado por: ${doc.user_name}</div>
                    <div>Data: ${formattedDate}</div>
                    <div>Tamanho: ${fileSize}</div>
                </div>
                <div class="btn-group">
                    <a href="/api/documents/${doc.id}" class="btn btn-sm btn-primary" target="_blank">
                        <i class="bi bi-download"></i> Baixar
                    </a>
                    ${currentUser && currentUser.is_admin ? `
                        <button class="btn btn-sm btn-danger" onclick="deleteDocument(${doc.id})">
                            <i class="bi bi-trash"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
    
    return card;
}

// Formatar tamanho de arquivo
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Excluir documento
function deleteDocument(documentId) {
    if (!confirm('Tem certeza que deseja excluir este documento?')) {
        return;
    }
    
    fetch(`/api/documents/${documentId}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            // Atualizar lista de documentos
            loadDocuments();
            
            // Mostrar mensagem de sucesso
            alert('Documento removido com sucesso!');
        }
    })
    .catch(error => {
        console.error('Erro ao excluir documento:', error);
        alert('Erro ao excluir documento. Tente novamente.');
    });
}
