from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Financial(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    subscription_type = db.Column(db.String(20), default='basic')  # premium, basic, individual
    balance = db.Column(db.Float, default=0.0)
    
    # Relacionamentos
    transactions = db.relationship('Transaction', backref='financial', lazy=True, cascade="all, delete-orphan")
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'subscription_type': self.subscription_type,
            'balance': self.balance,
            'transactions': [transaction.to_dict() for transaction in self.transactions]
        }

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    financial_id = db.Column(db.Integer, db.ForeignKey('financial.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    registered_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'financial_id': self.financial_id,
            'amount': self.amount,
            'description': self.description,
            'date': self.date.strftime('%Y-%m-%d %H:%M:%S'),
            'registered_by': self.registered_by
        }
