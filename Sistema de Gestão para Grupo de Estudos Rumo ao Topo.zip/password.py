from flask import Blueprint, request, jsonify, session, current_app
from src.models.user import User, db
from src.routes.user import login_required
import os
import uuid
import secrets
import time
from werkzeug.security import check_password_hash

password_bp = Blueprint('password', __name__)

# Dicionário para armazenar tokens temporários de visualização de senha
# Formato: {token: {'user_id': id, 'expires_at': timestamp, 'attempts': 0}}
password_view_tokens = {}

@password_bp.route('/profile/verify-password', methods=['POST'])
@login_required
def verify_password():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    data = request.get_json()
    
    if not data or 'password' not in data:
        return jsonify({'error': 'Senha é obrigatória'}), 400
    
    password = data['password']
    
    # Verificar se a senha está correta
    if not user.check_password(password):
        return jsonify({'error': 'Senha incorreta'}), 401
    
    # Gerar token temporário para visualização da senha
    token = secrets.token_urlsafe(32)
    expires_at = time.time() + 60  # Token válido por 60 segundos
    
    # Armazenar token com informações do usuário
    password_view_tokens[token] = {
        'user_id': user_id,
        'expires_at': expires_at,
        'attempts': 0
    }
    
    # Retornar senha mascarada e token
    masked_password = '•' * 8  # Placeholder para a senha
    
    return jsonify({
        'verified': True,
        'password_masked': masked_password,
        'token': token
    }), 200

@password_bp.route('/profile/reveal-password', methods=['POST'])
@login_required
def reveal_password():
    user_id = session.get('user_id')
    
    data = request.get_json()
    
    if not data or 'token' not in data:
        return jsonify({'error': 'Token é obrigatório'}), 400
    
    token = data['token']
    
    # Verificar se o token existe
    if token not in password_view_tokens:
        return jsonify({'error': 'Token inválido ou expirado'}), 401
    
    token_data = password_view_tokens[token]
    
    # Verificar se o token pertence ao usuário atual
    if token_data['user_id'] != user_id:
        return jsonify({'error': 'Token não autorizado para este usuário'}), 403
    
    # Verificar se o token expirou
    if time.time() > token_data['expires_at']:
        # Remover token expirado
        password_view_tokens.pop(token, None)
        return jsonify({'error': 'Token expirado'}), 401
    
    # Verificar número de tentativas (máximo 3)
    if token_data['attempts'] >= 3:
        # Remover token após 3 tentativas
        password_view_tokens.pop(token, None)
        return jsonify({'error': 'Número máximo de tentativas excedido'}), 401
    
    # Incrementar contador de tentativas
    token_data['attempts'] += 1
    
    # Buscar usuário
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    # Retornar senha original (apenas para visualização temporária)
    # Nota: Em um sistema real, seria necessário um mecanismo mais seguro
    # para recuperar a senha original, já que normalmente apenas o hash é armazenado
    
    # Simulação de senha para demonstração
    # Na prática, precisaríamos de um mecanismo para recuperar a senha original
    # ou implementar um sistema de redefinição de senha
    simulated_password = "Senha123"  # Apenas para demonstração
    
    return jsonify({
        'password': simulated_password
    }), 200

# Rota para limpar tokens expirados (pode ser chamada periodicamente)
@password_bp.route('/profile/cleanup-tokens', methods=['POST'])
def cleanup_tokens():
    # Verificar se é uma chamada interna autorizada
    if request.headers.get('X-Internal-Auth') != current_app.config['SECRET_KEY']:
        return jsonify({'error': 'Não autorizado'}), 403
    
    current_time = time.time()
    expired_tokens = [token for token, data in password_view_tokens.items() if current_time > data['expires_at']]
    
    for token in expired_tokens:
        password_view_tokens.pop(token, None)
    
    return jsonify({
        'message': f'Limpeza concluída. {len(expired_tokens)} tokens expirados removidos.'
    }), 200
