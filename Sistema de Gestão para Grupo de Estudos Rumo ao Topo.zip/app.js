// Variáveis globais
let currentUser = null;
let subjects = [];
let occurrenceTypes = [];
let allMembers = [];

// Elementos DOM
const loginScreen = document.getElementById('login-screen');
const adminPortal = document.getElementById('admin-portal');
const memberPortal = document.getElementById('member-portal');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se há um usuário logado
    checkCurrentUser();
    
    // Carregar matérias e tipos de ocorrências
    fetchSubjects();
    fetchOccurrenceTypes();
    
    // Configurar eventos de login e logout
    setupAuthEvents();
    
    // Configurar navegação
    setupNavigation();
    
    // Configurar eventos do portal do administrador
    setupAdminEvents();
    
    // Configurar eventos do portal do membro
    setupMemberEvents();
});

// Verificar usuário atual
function checkCurrentUser() {
    fetch('/api/current-user')
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Não autenticado');
            }
        })
        .then(data => {
            currentUser = data.user;
            showUserPortal();
        })
        .catch(error => {
            console.log('Usuário não autenticado:', error);
            showLoginScreen();
        });
}

// Mostrar portal adequado com base no tipo de usuário
function showUserPortal() {
    loginScreen.classList.add('d-none');
    
    if (currentUser.is_admin) {
        adminPortal.classList.remove('d-none');
        memberPortal.classList.add('d-none');
        loadMembers();
        document.querySelector('.admin-nav[data-page="admin-members"]').click();
    } else {
        adminPortal.classList.add('d-none');
        memberPortal.classList.remove('d-none');
        document.querySelector('.member-nav[data-page="member-grades"]').click();
        loadMemberGrades();
    }
}

// Mostrar tela de login
function showLoginScreen() {
    loginScreen.classList.remove('d-none');
    adminPortal.classList.add('d-none');
    memberPortal.classList.add('d-none');
    loginForm.reset();
    loginError.classList.add('d-none');
}

// Configurar eventos de autenticação
function setupAuthEvents() {
    // Login
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                loginError.textContent = data.error;
                loginError.classList.remove('d-none');
            } else {
                currentUser = data.user;
                showUserPortal();
            }
        })
        .catch(error => {
            console.error('Erro ao fazer login:', error);
            loginError.textContent = 'Erro ao conectar ao servidor. Tente novamente.';
            loginError.classList.remove('d-none');
        });
    });
    
    // Logout Administrador
    document.getElementById('admin-logout').addEventListener('click', function(e) {
        e.preventDefault();
        logout();
    });
    
    // Logout Membro
    document.getElementById('member-logout').addEventListener('click', function(e) {
        e.preventDefault();
        logout();
    });
}

// Função de logout
function logout() {
    fetch('/api/logout', {
        method: 'POST'
    })
    .then(() => {
        currentUser = null;
        showLoginScreen();
    })
    .catch(error => {
        console.error('Erro ao fazer logout:', error);
    });
}

// Configurar navegação
function setupNavigation() {
    // Navegação do Administrador
    document.querySelectorAll('.admin-nav').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const pageId = this.getAttribute('data-page');
            
            // Esconder todas as páginas
            document.querySelectorAll('.admin-page').forEach(page => {
                page.classList.add('d-none');
            });
            
            // Mostrar a página selecionada
            document.getElementById(pageId).classList.remove('d-none');
            
            // Atualizar navegação ativa
            document.querySelectorAll('.admin-nav').forEach(navLink => {
                navLink.classList.remove('active');
            });
            this.classList.add('active');
            
            // Carregar dados específicos da página
            if (pageId === 'admin-members') {
                loadMembers();
            } else if (pageId === 'admin-grades') {
                loadGradeData();
            } else if (pageId === 'admin-occurrences') {
                loadOccurrenceData();
            }
        });
    });
    
    // Navegação do Membro
    document.querySelectorAll('.member-nav').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const pageId = this.getAttribute('data-page');
            
            // Esconder todas as páginas
            document.querySelectorAll('.member-page').forEach(page => {
                page.classList.add('d-none');
            });
            
            // Mostrar a página selecionada
            document.getElementById(pageId).classList.remove('d-none');
            
            // Atualizar navegação ativa
            document.querySelectorAll('.member-nav').forEach(navLink => {
                navLink.classList.remove('active');
            });
            this.classList.add('active');
            
            // Carregar dados específicos da página
            if (pageId === 'member-grades') {
                loadMemberGrades();
            } else if (pageId === 'member-occurrences') {
                loadMemberOccurrences();
            }
        });
    });
}

// Configurar eventos do portal do administrador
function setupAdminEvents() {
    // Adicionar membro
    document.getElementById('save-member-btn').addEventListener('click', function() {
        const name = document.getElementById('member-name').value;
        const email = document.getElementById('member-email').value;
        const password = document.getElementById('member-password').value;
        
        if (!name || !email || !password) {
            alert('Preencha todos os campos');
            return;
        }
        
        fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                // Fechar modal e recarregar membros
                const modal = bootstrap.Modal.getInstance(document.getElementById('addMemberModal'));
                modal.hide();
                document.getElementById('add-member-form').reset();
                loadMembers();
            }
        })
        .catch(error => {
            console.error('Erro ao adicionar membro:', error);
            alert('Erro ao adicionar membro. Tente novamente.');
        });
    });
    
    // Eventos de mudança de bimestre/matéria para notas
    document.getElementById('grade-bimester').addEventListener('change', loadGradeData);
    document.getElementById('grade-subject').addEventListener('change', loadGradeData);
    
    // Eventos de mudança de bimestre/matéria para ocorrências
    document.getElementById('occurrence-bimester').addEventListener('change', loadOccurrenceData);
    document.getElementById('occurrence-subject').addEventListener('change', loadOccurrenceData);
    
    // Adicionar ocorrência
    document.getElementById('save-occurrence-btn').addEventListener('click', function() {
        const userId = document.getElementById('occurrence-user-id').value;
        const occurrenceType = document.getElementById('occurrence-type').value;
        const bimester = document.getElementById('occurrence-bimester').value;
        const subject = document.getElementById('occurrence-subject').value;
        
        fetch('/api/occurrences', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                bimester: bimester,
                subject: subject,
                occurrence_type: occurrenceType
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                // Fechar modal e recarregar ocorrências
                const modal = bootstrap.Modal.getInstance(document.getElementById('addOccurrenceModal'));
                modal.hide();
                loadOccurrenceData();
            }
        })
        .catch(error => {
            console.error('Erro ao adicionar ocorrência:', error);
            alert('Erro ao adicionar ocorrência. Tente novamente.');
        });
    });
}

// Configurar eventos do portal do membro
function setupMemberEvents() {
    // Eventos de mudança de bimestre para notas
    document.getElementById('member-grade-bimester').addEventListener('change', loadMemberGrades);
    
    // Eventos de mudança de bimestre para ocorrências
    document.getElementById('member-occurrence-bimester').addEventListener('change', loadMemberOccurrences);
}

// Carregar lista de matérias
function fetchSubjects() {
    fetch('/api/subjects')
        .then(response => response.json())
        .then(data => {
            subjects = data.subjects;
            
            // Preencher selects de matérias
            const subjectSelects = [
                document.getElementById('grade-subject'),
                document.getElementById('occurrence-subject')
            ];
            
            subjectSelects.forEach(select => {
                if (select) {
                    select.innerHTML = '';
                    subjects.forEach(subject => {
                        const option = document.createElement('option');
                        option.value = subject;
                        option.textContent = subject.charAt(0).toUpperCase() + subject.slice(1);
                        select.appendChild(option);
                    });
                }
            });
            
            // Carregar dados iniciais se necessário
            if (currentUser && currentUser.is_admin) {
                loadGradeData();
                loadOccurrenceData();
            }
        })
        .catch(error => {
            console.error('Erro ao carregar matérias:', error);
        });
}

// Carregar tipos de ocorrências
function fetchOccurrenceTypes() {
    fetch('/api/occurrence-types')
        .then(response => response.json())
        .then(data => {
            occurrenceTypes = data.occurrence_types;
            
            // Preencher select de tipos de ocorrências
            const occurrenceTypeSelect = document.getElementById('occurrence-type');
            if (occurrenceTypeSelect) {
                occurrenceTypeSelect.innerHTML = '';
                occurrenceTypes.forEach(type => {
                    const option = document.createElement('option');
                    option.value = type;
                    option.textContent = type.charAt(0).toUpperCase() + type.slice(1);
                    occurrenceTypeSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error('Erro ao carregar tipos de ocorrências:', error);
        });
}

// Carregar membros
function loadMembers() {
    fetch('/api/users')
        .then(response => response.json())
        .then(data => {
            allMembers = data.users;
            const tableBody = document.getElementById('members-table-body');
            tableBody.innerHTML = '';
            
            allMembers.forEach(member => {
                const row = document.createElement('tr');
                
                const nameCell = document.createElement('td');
                nameCell.textContent = member.name;
                row.appendChild(nameCell);
                
                const emailCell = document.createElement('td');
                emailCell.textContent = member.email;
                row.appendChild(emailCell);
                
                const actionsCell = document.createElement('td');
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'btn btn-sm btn-danger';
                deleteBtn.innerHTML = '<i class="bi bi-trash"></i>';
                deleteBtn.addEventListener('click', function() {
                    if (confirm(`Tem certeza que deseja remover ${member.name}?`)) {
                        deleteMember(member.id);
                    }
                });
                actionsCell.appendChild(deleteBtn);
                row.appendChild(actionsCell);
                
                tableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Erro ao carregar membros:', error);
        });
}

// Remover membro
function deleteMember(userId) {
    fetch(`/api/users/${userId}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            loadMembers();
        }
    })
    .catch(error => {
        console.error('Erro ao remover membro:', error);
        alert('Erro ao remover membro. Tente novamente.');
    });
}

// Carregar dados de notas para o administrador
function loadGradeData() {
    const bimester = document.getElementById('grade-bimester').value;
    const subject = document.getElementById('grade-subject').value;
    
    // Primeiro, carregar todos os membros
    fetch('/api/users')
        .then(response => response.json())
        .then(userData => {
            allMembers = userData.users;
            
            // Depois, carregar as notas existentes
            return fetch(`/api/grades?bimester=${bimester}&subject=${subject}`);
        })
        .then(response => response.json())
        .then(gradeData => {
            const tableBody = document.getElementById('grades-table-body');
            tableBody.innerHTML = '';
            
            // Criar uma linha para cada membro
            allMembers.forEach(member => {
                const row = document.createElement('tr');
                
                // Encontrar a nota deste membro para esta matéria/bimestre
                const memberGrade = gradeData.grades.find(grade => grade.user_id === member.id);
                
                // Nome do aluno
                const nameCell = document.createElement('td');
                nameCell.textContent = member.name;
                row.appendChild(nameCell);
                
                // Células para L1, L2, L3, L4
                const gradeInputs = [];
                for (let i = 1; i <= 4; i++) {
                    const cell = document.createElement('td');
                    const input = document.createElement('input');
                    input.type = 'number';
                    input.className = 'form-control grade-input';
                    input.min = '0';
                    input.max = '10';
                
(Content truncated due to size limit. Use line ranges to read in chunks)