from flask import Blueprint, request, jsonify, session
from src.models.user import User, db
from functools import wraps
import json

user_bp = Blueprint('user', __name__)

# Decorator para verificar se o usuário está autenticado
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Não autorizado. Faça login para continuar.'}), 401
        return f(*args, **kwargs)
    return decorated_function

# Decorator para verificar se o usuário é administrador
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Não autorizado. Faça login para continuar.'}), 401
        
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            return jsonify({'error': 'Acesso restrito ao administrador.'}), 403
        
        return f(*args, **kwargs)
    return decorated_function

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or 'email' not in data or 'password' not in data:
        return jsonify({'error': 'Email e senha são obrigatórios'}), 400
    
    email = data['email']
    password = data['password']
    
    user = User.query.filter_by(email=email).first()
    
    if not user or not user.check_password(password):
        return jsonify({'error': 'Email ou senha inválidos'}), 401
    
    session['user_id'] = user.id
    
    return jsonify({
        'message': 'Login realizado com sucesso',
        'user': user.to_dict()
    }), 200

@user_bp.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({'message': 'Logout realizado com sucesso'}), 200

@user_bp.route('/current-user', methods=['GET'])
@login_required
def get_current_user():
    user = User.query.get(session['user_id'])
    if not user:
        session.pop('user_id', None)
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    return jsonify({'user': user.to_dict()}), 200

@user_bp.route('/register', methods=['POST'])
@admin_required
def register():
    data = request.get_json()
    
    if not data or 'email' not in data or 'password' not in data or 'name' not in data:
        return jsonify({'error': 'Email, senha e nome são obrigatórios'}), 400
    
    email = data['email']
    password = data['password']
    name = data['name']
    
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return jsonify({'error': 'Email já cadastrado'}), 400
    
    new_user = User(email=email, password=password, name=name, is_admin=False)
    
    db.session.add(new_user)
    db.session.commit()
    
    return jsonify({
        'message': 'Usuário cadastrado com sucesso',
        'user': new_user.to_dict()
    }), 201

@user_bp.route('/users', methods=['GET'])
@admin_required
def get_all_users():
    users = User.query.filter_by(is_admin=False).all()
    return jsonify({
        'users': [user.to_dict() for user in users]
    }), 200

@user_bp.route('/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user_id):
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    if user.is_admin:
        return jsonify({'error': 'Não é possível remover um administrador'}), 403
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': 'Usuário removido com sucesso'}), 200

# Rota para inicializar o administrador (deve ser chamada apenas uma vez)
@user_bp.route('/init-admin', methods=['POST'])
def init_admin():
    # Verifica se já existe algum administrador
    admin = User.query.filter_by(is_admin=True).first()
    if admin:
        return jsonify({'error': 'Administrador já existe'}), 400
    
    # Cria o administrador com as credenciais fornecidas
    admin = User(
        email="henriquefnci@gmail.com",
        password="Henrique@4",
        name="Administrador",
        is_admin=True
    )
    
    db.session.add(admin)
    db.session.commit()
    
    return jsonify({
        'message': 'Administrador inicializado com sucesso',
        'admin': admin.to_dict()
    }), 201
