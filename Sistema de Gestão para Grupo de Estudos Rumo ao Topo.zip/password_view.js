// Funções específicas para visualização segura de senha

// Função para solicitar visualização temporária da senha
function requestPasswordView() {
    // Mostrar modal de confirmação
    const confirmModal = new bootstrap.Modal(document.getElementById('confirmPasswordViewModal'));
    confirmModal.show();
}

// Função para confirmar e mostrar senha temporariamente
function confirmPasswordView() {
    const currentPassword = document.getElementById('confirm-view-password').value;
    
    if (!currentPassword) {
        alert('Por favor, digite sua senha atual para confirmar.');
        return;
    }
    
    // Verificar senha atual
    fetch('/api/profile/verify-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            password: currentPassword
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else if (data.verified) {
            // Fechar modal de confirmação
            const confirmModal = bootstrap.Modal.getInstance(document.getElementById('confirmPasswordViewModal'));
            confirmModal.hide();
            
            // Mostrar modal com senha
            showPasswordTemporarily(data.password_masked, data.token);
        } else {
            alert('Senha incorreta. Por favor, tente novamente.');
        }
    })
    .catch(error => {
        console.error('Erro ao verificar senha:', error);
        alert('Erro ao verificar senha. Tente novamente.');
    });
}

// Função para mostrar senha temporariamente
function showPasswordTemporarily(maskedPassword, token) {
    // Preencher o campo com a senha mascarada
    document.getElementById('masked-password').value = maskedPassword;
    document.getElementById('password-view-token').value = token;
    
    // Mostrar modal
    const viewModal = new bootstrap.Modal(document.getElementById('viewPasswordModal'));
    viewModal.show();
    
    // Configurar temporizador para expirar a visualização
    const timerElement = document.getElementById('password-view-timer');
    let secondsLeft = 30; // 30 segundos para visualizar
    
    timerElement.textContent = secondsLeft;
    
    const timer = setInterval(() => {
        secondsLeft--;
        timerElement.textContent = secondsLeft;
        
        if (secondsLeft <= 0) {
            clearInterval(timer);
            const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewPasswordModal'));
            if (viewModal) {
                viewModal.hide();
            }
        }
    }, 1000);
    
    // Limpar timer se o modal for fechado manualmente
    document.getElementById('viewPasswordModal').addEventListener('hidden.bs.modal', function () {
        clearInterval(timer);
    }, { once: true });
}

// Função para revelar senha temporariamente
function revealPassword() {
    const token = document.getElementById('password-view-token').value;
    
    fetch('/api/profile/reveal-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            token: token
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else if (data.password) {
            const passwordField = document.getElementById('masked-password');
            const revealBtn = document.getElementById('reveal-password-btn');
            
            // Mostrar senha real
            passwordField.value = data.password;
            revealBtn.textContent = 'Ocultar Senha';
            revealBtn.onclick = hidePassword;
            
            // Configurar timer para ocultar automaticamente após 5 segundos
            setTimeout(() => {
                hidePassword();
            }, 5000);
        }
    })
    .catch(error => {
        console.error('Erro ao revelar senha:', error);
        alert('Erro ao revelar senha. Tente novamente.');
    });
}

// Função para ocultar senha novamente
function hidePassword() {
    const passwordField = document.getElementById('masked-password');
    const revealBtn = document.getElementById('reveal-password-btn');
    
    // Obter senha mascarada novamente
    fetch('/api/profile/password')
        .then(response => response.json())
        .then(data => {
            passwordField.value = data.password_placeholder;
            revealBtn.textContent = 'Revelar Senha';
            revealBtn.onclick = revealPassword;
        });
}

// Adicionar ao carregamento da página
document.addEventListener('DOMContentLoaded', function() {
    // Configurar botão de visualização de senha no perfil
    const viewPasswordBtn = document.getElementById('view-password-btn');
    if (viewPasswordBtn) {
        viewPasswordBtn.addEventListener('click', requestPasswordView);
    }
    
    // Configurar botão de confirmação
    const confirmViewBtn = document.getElementById('confirm-view-btn');
    if (confirmViewBtn) {
        confirmViewBtn.addEventListener('click', confirmPasswordView);
    }
    
    // Configurar botão de revelar senha
    const revealPasswordBtn = document.getElementById('reveal-password-btn');
    if (revealPasswordBtn) {
        revealPasswordBtn.addEventListener('click', revealPassword);
    }
});
