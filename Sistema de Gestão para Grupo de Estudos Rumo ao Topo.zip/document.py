from flask_sqlalchemy import SQLAlchemy
from src.models.user import db, User
import datetime

class Document(db.Model):
    __tablename__ = 'documents'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    bimester = db.Column(db.Integer, nullable=False)  # 1, 2, 3 ou 4
    subject = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=False)
    file_size = db.Column(db.Integer, nullable=False)  # Tamanho em bytes
    file_type = db.Column(db.String(50), nullable=False)  # Tipo MIME
    upload_date = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    # Relacionamento com o usuário que fez o upload
    user = db.relationship('User', backref=db.backref('documents', lazy=True))
    
    def __init__(self, user_id, bimester, subject, title, file_path, file_size, file_type, description=None):
        self.user_id = user_id
        self.bimester = bimester
        self.subject = subject
        self.title = title
        self.description = description
        self.file_path = file_path
        self.file_size = file_size
        self.file_type = file_type
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_name': self.user.name if self.user else None,
            'bimester': self.bimester,
            'subject': self.subject,
            'title': self.title,
            'description': self.description,
            'file_path': self.file_path,
            'file_size': self.file_size,
            'file_type': self.file_type,
            'upload_date': self.upload_date.isoformat() if self.upload_date else None
        }
