from flask_sqlalchemy import SQLAlchemy
from src.models.user import db, User

class Occurrence(db.Model):
    __tablename__ = 'occurrences'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    bimester = db.Column(db.Integer, nullable=False)  # 1, 2, 3 ou 4
    subject = db.Column(db.String(50), nullable=False)
    occurrence_type = db.Column(db.String(50), nullable=False)
    
    user = db.relationship('User', backref=db.backref('occurrences', lazy=True))
    
    def __init__(self, user_id, bimester, subject, occurrence_type):
        self.user_id = user_id
        self.bimester = bimester
        self.subject = subject
        self.occurrence_type = occurrence_type
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'bimester': self.bimester,
            'subject': self.subject,
            'occurrence_type': self.occurrence_type
        }
