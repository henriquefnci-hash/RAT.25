// Funções para o sistema de chat

// Elementos DOM para chat
let chatContainer;
let messagesList;
let messageForm;
let messageInput;
let imageInput;
let lastMessageId = 0;
let isLoadingMessages = false;
let messagePollingInterval;

// Inicialização do chat
document.addEventListener('DOMContentLoaded', function() {
    // Configuração anterior mantida...
    
    // Configurar eventos de chat
    setupChatEvents();
    
    // Iniciar polling de mensagens
    startMessagePolling();
});

// Configurar eventos relacionados ao chat
function setupChatEvents() {
    // Elementos do chat
    chatContainer = document.getElementById('chat-container');
    messagesList = document.getElementById('messages-list');
    messageForm = document.getElementById('message-form');
    messageInput = document.getElementById('message-input');
    imageInput = document.getElementById('message-image');
    
    // Botão para abrir chat
    const openChatBtn = document.getElementById('open-chat-btn');
    if (openChatBtn) {
        openChatBtn.addEventListener('click', function() {
            toggleChat();
        });
    }
    
    // Formulário de envio de mensagem
    if (messageForm) {
        messageForm.addEventListener('submit', function(e) {
            e.preventDefault();
            sendMessage();
        });
    }
    
    // Botão de anexar imagem
    const attachImageBtn = document.getElementById('attach-image-btn');
    if (attachImageBtn) {
        attachImageBtn.addEventListener('click', function() {
            imageInput.click();
        });
    }
    
    // Preview de imagem selecionada
    if (imageInput) {
        imageInput.addEventListener('change', function() {
            showImagePreview();
        });
    }
    
    // Botão para cancelar imagem
    const cancelImageBtn = document.getElementById('cancel-image-btn');
    if (cancelImageBtn) {
        cancelImageBtn.addEventListener('click', function() {
            cancelImageUpload();
        });
    }
    
    // Botão para fechar chat
    const closeChatBtn = document.getElementById('close-chat-btn');
    if (closeChatBtn) {
        closeChatBtn.addEventListener('click', function() {
            toggleChat();
        });
    }
    
    // Carregar mensagens iniciais
    loadMessages();
}

// Alternar visibilidade do chat
function toggleChat() {
    if (chatContainer) {
        chatContainer.classList.toggle('chat-open');
        
        // Se o chat foi aberto, rolar para a última mensagem
        if (chatContainer.classList.contains('chat-open')) {
            scrollToBottom();
            
            // Marcar mensagens como lidas
            markAllMessagesAsRead();
        }
    }
}

// Carregar mensagens
function loadMessages(beforeId = null) {
    if (isLoadingMessages) return;
    
    isLoadingMessages = true;
    
    // Construir URL com parâmetros
    let url = '/api/messages';
    const params = new URLSearchParams();
    params.append('limit', 50);
    
    if (beforeId) {
        params.append('before_id', beforeId);
    }
    
    url += '?' + params.toString();
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            isLoadingMessages = false;
            
            if (data.error) {
                console.error('Erro ao carregar mensagens:', data.error);
                return;
            }
            
            if (data.messages.length === 0) {
                // Não há mais mensagens para carregar
                return;
            }
            
            // Armazenar o ID da primeira mensagem para paginação
            const firstMessageId = data.messages[0].id;
            
            // Renderizar mensagens
            renderMessages(data.messages, beforeId !== null);
            
            // Atualizar último ID de mensagem
            if (!beforeId && data.messages.length > 0) {
                lastMessageId = data.messages[data.messages.length - 1].id;
            }
            
            // Adicionar botão "Carregar mais" se necessário
            if (data.messages.length === 50 && !document.getElementById('load-more-btn')) {
                addLoadMoreButton(firstMessageId);
            }
            
            // Rolar para o final se não for carregamento de mensagens antigas
            if (!beforeId) {
                scrollToBottom();
            }
        })
        .catch(error => {
            isLoadingMessages = false;
            console.error('Erro ao carregar mensagens:', error);
        });
}

// Renderizar mensagens
function renderMessages(messages, prepend = false) {
    if (!messagesList) return;
    
    // Criar elementos de mensagem
    const messageElements = messages.map(message => createMessageElement(message));
    
    if (prepend) {
        // Adicionar no início da lista (mensagens mais antigas)
        const loadMoreBtn = document.getElementById('load-more-btn');
        if (loadMoreBtn) {
            loadMoreBtn.remove();
        }
        
        messageElements.forEach(element => {
            messagesList.insertBefore(element, messagesList.firstChild);
        });
    } else {
        // Adicionar no final da lista (mensagens mais recentes)
        messageElements.forEach(element => {
            messagesList.appendChild(element);
        });
    }
}

// Criar elemento de mensagem
function createMessageElement(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.dataset.id = message.id;
    
    // Verificar se a mensagem é do usuário atual
    const isCurrentUser = message.sender_id === currentUser.id;
    messageDiv.classList.add(isCurrentUser ? 'message-sent' : 'message-received');
    
    // Criar conteúdo da mensagem
    let messageContent = '';
    
    // Adicionar informações do remetente (apenas para mensagens recebidas)
    if (!isCurrentUser) {
        messageContent += `
            <div class="message-sender">
                ${message.sender_profile_picture ? 
                    `<img src="${message.sender_profile_picture}" class="sender-avatar" alt="${message.sender_name}">` : 
                    `<div class="sender-avatar-placeholder">${message.sender_name.charAt(0)}</div>`
                }
                <span class="sender-name">${message.sender_name}</span>
            </div>
        `;
    }
    
    // Adicionar conteúdo da mensagem
    messageContent += `<div class="message-bubble">`;
    
    // Texto da mensagem
    if (message.content) {
        messageContent += `<div class="message-text">${formatMessageText(message.content)}</div>`;
    }
    
    // Imagem da mensagem
    if (message.image_url) {
        messageContent += `
            <div class="message-image">
                <img src="${message.image_url}" alt="Imagem" onclick="openImagePreview('${message.image_url}')">
            </div>
        `;
    }
    
    // Timestamp
    const messageDate = new Date(message.timestamp);
    const formattedTime = messageDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    
    messageContent += `
            <div class="message-time">${formattedTime}</div>
        </div>
    `;
    
    // Adicionar opções (apenas para mensagens enviadas pelo usuário atual)
    if (isCurrentUser) {
        messageContent += `
            <div class="message-options">
                <button class="btn btn-sm btn-link text-danger" onclick="deleteMessage(${message.id})">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `;
    }
    
    messageDiv.innerHTML = messageContent;
    return messageDiv;
}

// Formatar texto da mensagem (converter URLs, emojis, etc.)
function formatMessageText(text) {
    // Converter URLs em links clicáveis
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    text = text.replace(urlRegex, url => `<a href="${url}" target="_blank">${url}</a>`);
    
    // Converter quebras de linha em <br>
    text = text.replace(/\n/g, '<br>');
    
    return text;
}

// Enviar mensagem
function sendMessage() {
    const content = messageInput.value.trim();
    const hasImage = imageInput.files.length > 0;
    
    // Verificar se há conteúdo para enviar
    if (!content && !hasImage) {
        return;
    }
    
    // Desabilitar botão de envio
    const sendButton = document.querySelector('#message-form button[type="submit"]');
    sendButton.disabled = true;
    
    if (hasImage) {
        // Enviar mensagem com imagem usando FormData
        const formData = new FormData();
        formData.append('content', content);
        formData.append('image', imageInput.files[0]);
        
        fetch('/api/messages', {
            method: 'POST',
            body: formData
        })
        .then(handleMessageResponse)
        .catch(handleMessageError);
    } else {
        // Enviar mensagem de texto simples
        fetch('/api/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ content })
        })
        .then(handleMessageResponse)
        .catch(handleMessageError);
    }
    
    // Limpar campos
    messageInput.value = '';
    cancelImageUpload();
    
    // Focar no campo de entrada
    messageInput.focus();
}

// Manipular resposta do envio de mensagem
function handleMessageResponse(response) {
    // Reativar botão de envio
    const sendButton = document.querySelector('#message-form button[type="submit"]');
    sendButton.disabled = false;
    
    return response.json().then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            // Adicionar mensagem à lista
            const messageElement = createMessageElement(data.chat_message);
            messagesList.appendChild(messageElement);
            
            // Atualizar último ID de mensagem
            lastMessageId = data.chat_message.id;
            
            // Rolar para o final
            scrollToBottom();
        }
    });
}

// Manipular erro no envio de mensagem
function handleMessageError(error) {
    // Reativar botão de envio
    const sendButton = document.querySelector('#message-form button[type="submit"]');
    sendButton.disabled = false;
    
    console.error('Erro ao enviar mensagem:', error);
    alert('Erro ao enviar mensagem. Tente novamente.');
}

// Mostrar preview de imagem selecionada
function showImagePreview() {
    const imagePreviewContainer = document.getElementById('image-preview-container');
    const imagePreview = document.getElementById('image-preview');
    
    if (imageInput.files.length > 0) {
        const file = imageInput.files[0];
        
        // Verificar tipo de arquivo
        if (!file.type.match('image.*')) {
            alert('Por favor, selecione apenas imagens.');
            imageInput.value = '';
            return;
        }
        
        // Verificar tamanho do arquivo (máximo 5MB)
        const maxSize = 5 * 1024 * 1024; // 5MB em bytes
        if (file.size > maxSize) {
            alert('A imagem é muito grande. O tamanho máximo permitido é 5MB.');
            imageInput.value = '';
            return;
        }
        
        // Mostrar preview
        const reader = new FileReader();
        reader.onload = function(e) {
            imagePreview.src = e.target.result;
            imagePreviewContainer.classList.remove('d-none');
        };
        reader.readAsDataURL(file);
    }
}

// Cancelar upload de imagem
function cancelImageUpload() {
    imageInput.value = '';
    const imagePreviewContainer = document.getElementById('image-preview-container');
    imagePreviewContainer.classList.add('d-none');
}

// Abrir preview de imagem em tamanho maior
function openImagePreview(imageUrl) {
    const modal = new bootstrap.Modal(document.getElementById('imagePreviewModal'));
    document.getElementById('full-size-image').src = imageUrl;
    modal.show();
}

// Excluir mensagem
function deleteMessage(messageId) {
    if (!confirm('Tem certeza que deseja excluir esta mensagem?')) {
        return;
    }
    
    fetch(`/api/messages/${messageId}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            // Remover mensagem da lista
            const messageElement = document.querySelector(`.message[data-id="${messageId}"]`);
            if (messageElement) {
                messageElement.remove();
            }
        }
    })
    .catch(error => {
        console.error('Erro ao excluir mensagem:', error);
        alert('Erro ao excluir mensagem. Tente novamente.');
    });
}

// Adicionar botão "Carregar mais"
function addLoadMoreButton(firstMessageId) {
    const loadMoreBtn = document.createElement('div');
    loadMoreBtn.id = 'load-more-btn';
    loadMoreBtn.className = 'load-more-messages';
    loadMoreBtn.innerHTML = '<button class="btn btn-sm btn-outline-primary">Carregar mensagens anteriores</button>';
    loadMoreBtn.addEventListener('click', function() {
        loadMessages(firstMessageId);
    });
    
    messagesList.insertBefore(loadMoreBtn, messagesList.firstChild);
}

// Rolar para o final da lista de mensagens
function scrollToBottom() {
    if (messagesList) {
        messagesList.scrollTop = messagesList.scrollHeight;
    }
}

// Marcar todas as mensagens como lidas
function markAllMessagesAsRead() {
    // Implementação simplificada - em um sistema real, seria necessário
    // marcar cada mensagem individualmente como lida no servidor
    const unreadMessages = document.querySelectorAll('.message.unread');
    unreadMessages.forEach(message => {
        message.classList.remove('unread');
        
        // Enviar requisição para marcar como lida no servidor
        const messageId = message.dataset.id;
        fetch(`/api/messages/${messageId}/read`, {
            method: 'PUT'
        }).catch(error => {
            console.error('Erro ao marcar mensagem como lida:', error);
        });
    });
}

// Iniciar polling de novas mensagens
function startMessagePolling() {
    // Verificar novas mensagens a cada 5 segundos
    messagePollingInterval = setInterval(checkNewMessages, 5000);
}

// Verificar novas mensagens
function checkNewMessages() {
    if (!lastMessageId) return;
    
    // Buscar mensagens mais recentes que a última mensagem exibida
    fetch(`/api/messages?after_id=${lastMessageId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Erro ao verificar novas mensagens:', data.error);
                return;
            }
            
            if (data.messages.length > 0) {
                // Renderizar novas mensagens
                renderMessages(data.messages);
                
                // Atualizar último ID de mensagem
                lastMessageId = data.messages[data.messages.length - 1].id;
                
                // Rolar para o final se o chat estiver aberto
                if (chatContainer && chatContainer.classList.contains('chat-open')) {
                    scrollToBottom();
                    markAllMessagesAsRead();
                } else {
                    // Notificar sobre novas mensagens
                    notifyNewMessages(data.messages.length);
                }
            }
        })
        .catch(error => {
            console.error('Erro ao verificar novas mensagens:', error);
        });
}

// Notificar sobre novas mensagens
function notifyNewMessages(count) {
    const chatButton = document.getElementById('open-chat-btn');
    if (chatButton) {
        // Adicionar badge de notificação
        let badge = chatButton.querySelector('.chat-notification-badge');
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'chat-notification-badge 
(Content truncated due to size limit. Use line ranges to read in chunks)