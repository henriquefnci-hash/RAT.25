from flask import Blueprint, request, jsonify, current_app
import os
from werkzeug.utils import secure_filename
from src.models.message import db, Message
from src.models.user import User

chat_bp = Blueprint('chat', __name__)

@chat_bp.route('/messages', methods=['GET'])
def get_messages():
    sender_id = request.args.get('sender_id', type=int)
    receiver_id = request.args.get('receiver_id', type=int)
    
    if not sender_id or not receiver_id:
        return jsonify({'error': 'Parâmetros inválidos'}), 400
    
    # Buscar mensagens entre os dois usuários (em ambas as direções)
    messages = Message.query.filter(
        ((Message.sender_id == sender_id) & (Message.receiver_id == receiver_id)) |
        ((Message.sender_id == receiver_id) & (Message.receiver_id == sender_id))
    ).order_by(Message.timestamp).all()
    
    return jsonify([message.to_dict() for message in messages])

@chat_bp.route('/messages', methods=['POST'])
def send_message():
    data = request.form
    sender_id = data.get('sender_id', type=int)
    receiver_id = data.get('receiver_id', type=int)
    content = data.get('content')
    
    if not sender_id or not receiver_id:
        return jsonify({'error': 'Parâmetros inválidos'}), 400
    
    # Verificar se os usuários existem
    sender = User.query.get(sender_id)
    receiver = User.query.get(receiver_id)
    
    if not sender or not receiver:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    message = Message(
        sender_id=sender_id,
        receiver_id=receiver_id,
        content=content,
        message_type='text'
    )
    
    # Verificar se há arquivo anexado
    if 'file' in request.files:
        file = request.files['file']
        if file and file.filename:
            filename = secure_filename(file.filename)
            upload_folder = os.path.join(current_app.static_folder, 'uploads', 'chat')
            
            # Criar pasta se não existir
            os.makedirs(upload_folder, exist_ok=True)
            
            file_path = os.path.join(upload_folder, filename)
            file.save(file_path)
            
            # Atualizar mensagem para tipo arquivo
            message.message_type = 'file'
            message.file_path = os.path.join('uploads', 'chat', filename)
            message.file_name = filename
    
    db.session.add(message)
    db.session.commit()
    
    return jsonify(message.to_dict()), 201

@chat_bp.route('/messages/<int:message_id>', methods=['DELETE'])
def delete_message(message_id):
    message = Message.query.get_or_404(message_id)
    
    # Atualizar status para excluído
    message.status = 'deleted'
    db.session.commit()
    
    return jsonify({'message': 'Mensagem excluída com sucesso'})

@chat_bp.route('/users', methods=['GET'])
def get_users():
    current_user_id = request.args.get('current_user_id', type=int)
    
    if not current_user_id:
        return jsonify({'error': 'ID de usuário não fornecido'}), 400
    
    # Buscar todos os usuários exceto o atual
    users = User.query.filter(User.id != current_user_id).all()
    
    return jsonify([user.to_dict() for user in users])
