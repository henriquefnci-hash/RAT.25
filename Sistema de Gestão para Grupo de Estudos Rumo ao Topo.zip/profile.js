// Adicionar funcionalidades de perfil ao JavaScript existente

// Elementos DOM para perfil
let profileModal;
let profileForm;
let passwordModal;
let passwordForm;
let profilePictureModal;
let profilePictureForm;

// Inicialização adicional para perfil
document.addEventListener('DOMContentLoaded', function() {
    // Configuração anterior mantida...
    
    // Configurar eventos de perfil
    setupProfileEvents();
});

// Configurar eventos relacionados ao perfil
function setupProfileEvents() {
    // Botão de perfil no menu do usuário
    const profileMenuBtn = document.getElementById('profile-menu-btn');
    if (profileMenuBtn) {
        profileMenuBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showProfileModal();
        });
    }
    
    // Formulário de edição de perfil
    profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            updateProfile();
        });
    }
    
    // Formulário de alteração de senha
    passwordForm = document.getElementById('password-form');
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            updatePassword();
        });
    }
    
    // Formulário de upload de foto de perfil
    profilePictureForm = document.getElementById('profile-picture-form');
    if (profilePictureForm) {
        profilePictureForm.addEventListener('submit', function(e) {
            e.preventDefault();
            uploadProfilePicture();
        });
    }
    
    // Botão para mostrar senha
    const showPasswordBtn = document.getElementById('show-password-btn');
    if (showPasswordBtn) {
        showPasswordBtn.addEventListener('click', function() {
            togglePasswordVisibility();
        });
    }
    
    // Botão para abrir modal de alteração de senha
    const changePasswordBtn = document.getElementById('change-password-btn');
    if (changePasswordBtn) {
        changePasswordBtn.addEventListener('click', function() {
            showPasswordModal();
        });
    }
    
    // Botão para abrir modal de upload de foto
    const changePictureBtn = document.getElementById('change-picture-btn');
    if (changePictureBtn) {
        changePictureBtn.addEventListener('click', function() {
            showProfilePictureModal();
        });
    }
}

// Mostrar modal de perfil com dados atuais
function showProfileModal() {
    // Buscar dados atuais do perfil
    fetch('/api/profile')
        .then(response => response.json())
        .then(data => {
            if (data.profile) {
                // Preencher formulário com dados atuais
                document.getElementById('profile-name').value = data.profile.name || '';
                document.getElementById('profile-email').value = data.profile.email || '';
                document.getElementById('profile-phone').value = data.profile.phone || '';
                
                // Atualizar imagem de perfil se existir
                const profileImage = document.getElementById('current-profile-image');
                if (profileImage && data.profile.profile_picture_url) {
                    profileImage.src = data.profile.profile_picture_url;
                    profileImage.classList.remove('d-none');
                } else if (profileImage) {
                    profileImage.classList.add('d-none');
                }
                
                // Mostrar modal
                profileModal = new bootstrap.Modal(document.getElementById('profileModal'));
                profileModal.show();
            }
        })
        .catch(error => {
            console.error('Erro ao carregar perfil:', error);
            alert('Erro ao carregar dados do perfil. Tente novamente.');
        });
}

// Atualizar dados do perfil
function updateProfile() {
    const name = document.getElementById('profile-name').value;
    const email = document.getElementById('profile-email').value;
    const phone = document.getElementById('profile-phone').value;
    
    fetch('/api/profile', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name,
            email,
            phone
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            // Atualizar dados do usuário atual
            currentUser = data.profile;
            
            // Atualizar nome do usuário na interface
            const userNameElements = document.querySelectorAll('.current-user-name');
            userNameElements.forEach(el => {
                el.textContent = currentUser.name;
            });
            
            // Fechar modal
            profileModal.hide();
            
            // Mostrar mensagem de sucesso
            alert('Perfil atualizado com sucesso!');
        }
    })
    .catch(error => {
        console.error('Erro ao atualizar perfil:', error);
        alert('Erro ao atualizar perfil. Tente novamente.');
    });
}

// Mostrar modal de alteração de senha
function showPasswordModal() {
    // Limpar formulário
    passwordForm.reset();
    
    // Mostrar modal
    passwordModal = new bootstrap.Modal(document.getElementById('passwordModal'));
    passwordModal.show();
}

// Atualizar senha
function updatePassword() {
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    // Validar senhas
    if (newPassword !== confirmPassword) {
        alert('A nova senha e a confirmação não coincidem.');
        return;
    }
    
    fetch('/api/profile/password', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            current_password: currentPassword,
            new_password: newPassword
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            // Fechar modal
            passwordModal.hide();
            
            // Mostrar mensagem de sucesso
            alert('Senha atualizada com sucesso!');
        }
    })
    .catch(error => {
        console.error('Erro ao atualizar senha:', error);
        alert('Erro ao atualizar senha. Tente novamente.');
    });
}

// Alternar visibilidade da senha
function togglePasswordVisibility() {
    const passwordField = document.getElementById('current-password');
    const newPasswordField = document.getElementById('new-password');
    const confirmPasswordField = document.getElementById('confirm-password');
    
    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        if (newPasswordField) newPasswordField.type = 'text';
        if (confirmPasswordField) confirmPasswordField.type = 'text';
        document.getElementById('show-password-btn').textContent = 'Ocultar Senha';
    } else {
        passwordField.type = 'password';
        if (newPasswordField) newPasswordField.type = 'password';
        if (confirmPasswordField) confirmPasswordField.type = 'password';
        document.getElementById('show-password-btn').textContent = 'Mostrar Senha';
    }
}

// Mostrar modal de upload de foto de perfil
function showProfilePictureModal() {
    // Limpar formulário
    profilePictureForm.reset();
    
    // Mostrar modal
    profilePictureModal = new bootstrap.Modal(document.getElementById('profilePictureModal'));
    profilePictureModal.show();
}

// Upload de foto de perfil
function uploadProfilePicture() {
    const fileInput = document.getElementById('profile-picture-file');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Selecione uma imagem para upload.');
        return;
    }
    
    // Validar tipo de arquivo
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
        alert('Formato de arquivo não permitido. Use JPG, PNG ou GIF.');
        return;
    }
    
    // Criar FormData para envio do arquivo
    const formData = new FormData();
    formData.append('picture', file);
    
    fetch('/api/profile/picture', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            // Atualizar URL da foto de perfil no usuário atual
            currentUser.profile_picture_url = data.profile_picture_url;
            
            // Atualizar imagens de perfil na interface
            const profileImages = document.querySelectorAll('.profile-image');
            profileImages.forEach(img => {
                img.src = data.profile_picture_url;
                img.classList.remove('d-none');
            });
            
            // Fechar modal
            profilePictureModal.hide();
            
            // Mostrar mensagem de sucesso
            alert('Foto de perfil atualizada com sucesso!');
        }
    })
    .catch(error => {
        console.error('Erro ao fazer upload da foto:', error);
        alert('Erro ao fazer upload da foto. Tente novamente.');
    });
}
