from flask_sqlalchemy import SQLAlchemy
from src.models.user import db, User

class Grade(db.Model):
    __tablename__ = 'grades'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    bimester = db.Column(db.Integer, nullable=False)  # 1, 2, 3 ou 4
    subject = db.Column(db.String(50), nullable=False)
    l1 = db.Column(db.Float, nullable=True)
    l2 = db.Column(db.Float, nullable=True)
    l3 = db.Column(db.Float, nullable=True)
    l4 = db.Column(db.Float, nullable=True)
    
    user = db.relationship('User', backref=db.backref('grades', lazy=True))
    
    def __init__(self, user_id, bimester, subject, l1=None, l2=None, l3=None, l4=None):
        self.user_id = user_id
        self.bimester = bimester
        self.subject = subject
        self.l1 = l1
        self.l2 = l2
        self.l3 = l3
        self.l4 = l4
    
    def calculate_average(self):
        grades = [g for g in [self.l1, self.l2, self.l3, self.l4] if g is not None]
        if not grades:
            return None
        return sum(grades) / len(grades)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'bimester': self.bimester,
            'subject': self.subject,
            'l1': self.l1,
            'l2': self.l2,
            'l3': self.l3,
            'l4': self.l4,
            'average': self.calculate_average()
        }
