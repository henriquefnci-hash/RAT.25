from flask import Blueprint, request, jsonify, session, current_app
from src.models.user import User, db
from src.routes.user import login_required
import os
from werkzeug.utils import secure_filename
import uuid

profile_bp = Blueprint('profile', __name__)

@profile_bp.route('/profile', methods=['GET'])
@login_required
def get_profile():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    return jsonify({
        'profile': user.to_dict()
    }), 200

@profile_bp.route('/profile', methods=['PUT'])
@login_required
def update_profile():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    data = request.get_json()
    
    # Atualizar campos permitidos
    if 'name' in data:
        user.name = data['name']
    
    if 'email' in data:
        # Verificar se o email já está em uso por outro usuário
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user and existing_user.id != user.id:
            return jsonify({'error': 'Este email já está em uso'}), 400
        user.email = data['email']
    
    if 'phone' in data:
        user.phone = data['phone']
    
    db.session.commit()
    
    return jsonify({
        'message': 'Perfil atualizado com sucesso',
        'profile': user.to_dict()
    }), 200

@profile_bp.route('/profile/password', methods=['GET'])
@login_required
def view_password():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    # Retornar apenas um placeholder para a senha
    # A senha real nunca deve ser retornada, mesmo que esteja armazenada como hash
    return jsonify({
        'message': 'Por razões de segurança, a senha real não pode ser exibida',
        'password_placeholder': '••••••••'
    }), 200

@profile_bp.route('/profile/password', methods=['PUT'])
@login_required
def update_password():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    data = request.get_json()
    
    if not data or 'current_password' not in data or 'new_password' not in data:
        return jsonify({'error': 'Senha atual e nova senha são obrigatórias'}), 400
    
    # Verificar se a senha atual está correta
    if not user.check_password(data['current_password']):
        return jsonify({'error': 'Senha atual incorreta'}), 401
    
    # Atualizar a senha
    user.update_password(data['new_password'])
    db.session.commit()
    
    return jsonify({
        'message': 'Senha atualizada com sucesso'
    }), 200

@profile_bp.route('/profile/picture', methods=['POST'])
@login_required
def upload_profile_picture():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': 'Usuário não encontrado'}), 404
    
    if 'picture' not in request.files:
        return jsonify({'error': 'Nenhuma imagem enviada'}), 400
    
    file = request.files['picture']
    
    if file.filename == '':
        return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
    
    if file:
        # Verificar extensão do arquivo
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif'}
        if '.' not in file.filename or file.filename.rsplit('.', 1)[1].lower() not in allowed_extensions:
            return jsonify({'error': 'Formato de arquivo não permitido. Use PNG, JPG, JPEG ou GIF'}), 400
        
        # Criar diretório para imagens de perfil se não existir
        profile_pics_dir = os.path.join(current_app.static_folder, 'profile_pictures')
        os.makedirs(profile_pics_dir, exist_ok=True)
        
        # Gerar nome de arquivo único
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        file_path = os.path.join(profile_pics_dir, unique_filename)
        
        # Salvar arquivo
        file.save(file_path)
        
        # Atualizar URL da foto de perfil no banco de dados
        user.profile_picture_url = f"/static/profile_pictures/{unique_filename}"
        db.session.commit()
        
        return jsonify({
            'message': 'Foto de perfil atualizada com sucesso',
            'profile_picture_url': user.profile_picture_url
        }), 200
    
    return jsonify({'error': 'Erro ao processar o arquivo'}), 500
